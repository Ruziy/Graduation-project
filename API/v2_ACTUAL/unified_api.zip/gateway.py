from __future__ import annotations

import os
import sys
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from jinja2 import Environment, FileSystemLoader, select_autoescape

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR / "optimizer_part"))
sys.path.insert(0, str(BASE_DIR / "faceRec_part"))

# Import sub-apps as-is
# optimizer_part has FastAPI app inside main_V3.py named 'app'
import importlib
opt_module = importlib.import_module("main_V3")
optimizer_app = getattr(opt_module, "app")

# faceRec_part has FastAPI app inside app.py named 'app'
face_module = importlib.import_module("app")
face_app = getattr(face_module, "app")

# Unified gateway
app = FastAPI(title="🧩 Unified API Hub")

# Serve hub using optimizer's CSS for consistent style
jinja_env = Environment(
    loader=FileSystemLoader(str(BASE_DIR / "templates")),
    autoescape=select_autoescape(["html", "xml"]),
)

@app.get("/", response_class=HTMLResponse)
async def hub():
    html = jinja_env.get_template("hub.html").render()
    return HTMLResponse(html)

# Mount subapps under prefixes
app.mount("/optimizer", optimizer_app)
app.mount("/face", face_app)

# Convenience health
@app.get("/healthz", response_class=HTMLResponse)
async def healthz():
    return HTMLResponse("ok")
